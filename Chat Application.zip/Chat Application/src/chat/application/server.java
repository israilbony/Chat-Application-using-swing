/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.application;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.List;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class server extends Frame implements ActionListener{

   public static final int port=8085;
	public static int m;
	public static Button sendBut, exitBut ,room1,room2,room3;
    public static java.awt.List list,list1,list2,list3;
    public static Chatroom1 ch1;
   //public static Chatroom2 ch2;
   // public static Chatroom3 ch3;
	public static Vector clients=new Vector();
    public static TextField text;
    public static server f;
   // public static serverone s1;
     public server()
    {
	}
    public static void main(String[] args) {
                   boolean k=true;
		ServerSocket s=null;
		Image Icon = Toolkit.getDefaultToolkit().getImage("H:\\my project\\Chat Application\\src\\chat\\application\\hi.gif");
                try
		{
			s=new ServerSocket(8085);
		}
		catch(IOException ie)
		{
			System.out.println("Couldn't Listen on Port : 1053");
		}

		f=new server();
		f.setSize(500, 300);
		f.setTitle("Server Application");
		f.setIconImage(Icon);
                 f.setBackground(Color.lightGray);
                 f.setLayout(new GridLayout(3, 4));
                 
             
Panel panels[] = new Panel[12];
                                panels[0] = new Panel();
		                panels[1] = new Panel();
		                panels[5] = new Panel();
		                panels[6] = new Panel();
                                panels[0].setLayout(new BorderLayout());
                           panels[1].setLayout(new FlowLayout(FlowLayout.LEFT));
		                panels[5].setLayout(new GridLayout(1, 3));
		                panels[6].setLayout(new GridLayout(2, 3));
                                 sendBut = new Button("Send");
		                exitBut = new Button("Exit");
		                room1=new Button("Chat Room 1");
		                room2=new Button("Chat Room 2");
		                room3=new Button("Chat Room 3");
		                room1.addActionListener(f);
		                room2.addActionListener(f);
		                room3.addActionListener(f);
                                list = new java.awt.List();
		                list1 = new java.awt.List();
		                list2 = new java.awt.List();
		                list3 = new java.awt.List();

		                list.addItem("Server Started");
                                text = new TextField(25);


		                panels[0].add(list);

		                panels[6].add(list1);
		                panels[6].add(list2);
		                panels[6].add(list3);

		                panels[1].add(text);
		                panels[1].add(sendBut);
		                panels[1].add(exitBut);

		                panels[6].add(room1);
		                panels[6].add(room2);
		                panels[6].add(room3);
                                f.add(panels[0]);


                    f.add(panels[1]);
                    f.add(panels[6]);
    
                f.setVisible(true);
              
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      
      if(e.getSource()==room1)
      {
            ch1=new Chatroom1("Chatroom 1",f);
         
      }
      if(e.getSource()==room2)
      {
            ch1=new Chatroom1("Chatroom 2",f);
         
      }
      if(e.getSource()==room3)
      {
            ch1=new Chatroom1("Chatroom 3",f);
         
      }
      if(e.getSource()==exitBut)
      {
         System.exit(0);
      }
      
        
    }

 
    
}
