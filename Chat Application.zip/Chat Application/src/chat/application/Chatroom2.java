/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.application;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.util.Vector;

public class Chatroom2 extends Dialog implements ActionListener{
    public static List list,list1;
   // server s;
	TextArea ta1;
       static Vector cs = new Vector();
	static Vector c = new Vector();
        static int first = 0;
	Button bs,close;
	String send;
	//public static serverone t;
	BufferedWriter temp;
        public Chatroom2(String s,server f){
	super(f,s,false);

	

		this.setSize(400,400);

		this.setLayout(new GridLayout(1,2));
		list = new List();
		list1 = new List();
		Panel p1 = new Panel();
		Panel p2 = new Panel();
		Panel p4 = new Panel();

		p1.setLayout(new BorderLayout());
		p2.setLayout(new BorderLayout());
	    p4.setLayout(new FlowLayout(FlowLayout.CENTER));
        p1.add(list1,BorderLayout.CENTER);


       p2.add(list,BorderLayout.CENTER);

	     Label ld = new Label("This is " + s);
	    p1.add(ld,BorderLayout.NORTH);

	    Label lc = new Label("Online Users");
	    p2.add(lc,BorderLayout.NORTH);


        ta1 = new TextArea(2,5);
        p1.add(ta1,BorderLayout.SOUTH);

        bs = new Button("Send");
        close = new Button("Exit");
        bs.addActionListener(this);
        close.addActionListener(this);
        p4.add(bs);
        p4.add(close);
        p2.add(p4,BorderLayout.SOUTH);

        this.add(p1);
        this.add(p2);
       setVisible(true);
                
        }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==close)
      {
          this.dispose();
      }
        if(e.getSource()==bs)
        {
            if((ta1.getText()).length()>0)
            {
            list1.add("<classroom2>"+ta1.getText());
            ta1.setText("");
            }
        }
      }
    }