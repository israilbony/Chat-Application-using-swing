
package chat.application;

import static chat.application.server.f;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import javax.swing.JOptionPane;


public class client extends JFrame implements ActionListener{
public Label l1,l2,l3,l4;
	public JButton Ok,Cancel;
	public TextField login,pwd;
         JPasswordField value;
	public Checkbox Chatroom1,Chatroom2,Chatroom3;
	public CheckboxGroup cbg;
	public client1 c1;
	public static String l,c,p,a;
        public static Frame f;
   public client()
    {
       f=new Frame("Client Login Page");
      f.setSize(400, 300);
      f.setLayout(new GridLayout(4,1));
      l1=new Label("Chatrooms");
           
                Panel p1 = new Panel();
		Panel p2 = new Panel();
		Panel p3 = new Panel();
           
		Panel p4 = new Panel();
            p1.setLayout(new FlowLayout(FlowLayout.CENTER));
                p1.add(l1);
                cbg = new CheckboxGroup();
        Chatroom1 = new Checkbox("Chatroom1",cbg,true);
        Chatroom2 = new Checkbox("Chatroom2",cbg,false);
        Chatroom3 = new Checkbox("Chatroom3",cbg,false);
        
        p2.setLayout(new FlowLayout(FlowLayout.CENTER));

                p2.add(Chatroom1);
                p2.add(Chatroom2);
                p2.add(Chatroom3);
                l2=new Label("UserName");
                login=new TextField(10);
                l3=new Label("Password");
            pwd=new TextField(10);
             pwd.setEchoChar('*');
            value = new JPasswordField(10);   
             p3.setLayout(new FlowLayout(FlowLayout.CENTER));
             p3.add(l2);p3.add(login);p3.add(l3);p3.add(pwd);
             Ok=new JButton("OK"); Cancel=new JButton("Cancel");
            p4.setLayout(new FlowLayout(FlowLayout.CENTER));
            p4.add(Ok);p4.add(Cancel);
            Ok.addActionListener(this);
            Cancel.addActionListener(this);
                f.add(p1);f.add(p2);f.add(p3);f.add(p4);
               Image Icon = Toolkit.getDefaultToolkit().getImage("hi.gif");
               f.setIconImage(Icon);
               f.setVisible(true);
              
       
        
    }
   public static void main(String a[] )
   {
       new client();
   }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource()==Ok)
        {
           
            if(login.getText().equals(pwd.getText()))
            {
             
                c1=new client1(this);
            
            }
            else
               JOptionPane.showMessageDialog(this,"Plese insert correctly UserName and Password"); 
        }
        
        if(e.getSource()==Cancel)
        {
            System.exit(0);
        }
    }
    
}


 class client1 extends Frame {
    
   public static Frame fr;
   public static client c;
   public static TextArea tx;
    client1(client cr)
    {
        this.c=cr;
        Image Icon = Toolkit.getDefaultToolkit().getImage("hi.gif") ;
        
        fr=new Frame("Client "+c.login.getText());
        fr.setIconImage(Icon);
        fr.setBackground(Color.lightGray);
        fr.setSize(400, 300);
       fr.setLayout(new GridLayout(1,2));
       Panel p1=new Panel();
       Panel p2=new Panel();
       Panel p3=new Panel();
       Panel p4=new Panel();
       Panel p5=new Panel();
       List list1=new List();
       List list2=new List();
       List list3=new List();
       p1.setLayout(new BorderLayout());
       p2.setLayout(new BorderLayout());
       p3.setLayout(new GridLayout(2,1));
       p4.setLayout(new GridLayout(2,1));
       p5.setLayout(new FlowLayout(FlowLayout.CENTER));
       p1.add(list1,BorderLayout.CENTER);
       p2.add(list2,BorderLayout.CENTER);
       Label l1=new Label("You are in "+c.cbg.getSelectedCheckbox().getAccessibleContext());
       Label l2=new Label("Online User");
       Button Sent=new Button("Sent");
       Button Logout=new Button("Logout");
       tx = new TextArea(2,5);
     
      p1.add(l1,BorderLayout.NORTH);
      p2.add(l2,BorderLayout.NORTH);
      p3.add(list3);
      p4.add(tx);
      p5.add(Sent);p5.add(Logout);
      p4.add(p5);
      p3.add(p4);
      p2.add(p3);
      
       
        fr.add(p1);fr.add(p2);
        c.f.dispose();
        fr.setVisible(true);
    }
}